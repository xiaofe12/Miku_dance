# MikuShowcase

MikuShowcase adds one non-collidable Miku performance display to PEAK.

The same display is shown in the Airport lobby by default, and you can move it to a grounded spot near the player with a hotkey. Optional bundled music can play in sync with the dance loop.

For stronger scene lighting and shadows, PEAK_Visuals is recommended:
[glarmer-PEAK_Visuals](https://thunderstore.io/c/peak/p/glarmer/PEAK_Visuals/)

## What This Mod Does

- Spawns one display automatically in the Airport lobby.
- Lets you move that same display with a configurable hotkey.
- Keeps the model non-collidable so it is only used for presentation.
- Supports optional synced music playback.
- Uses one config file only: BepInEx/config/com.github.Thanks.MikuDance.cfg.

## Installation

1. Install BepInExPack for PEAK.
2. Install with Thunderstore, or extract this package into the PEAK game folder.
3. The runtime files should be placed in BepInEx/plugins.
4. The config file is generated automatically in BepInEx/config after the game starts.

## Package Contents

- com.github.Thanks.MikuShowcase.dll: main plugin.
- miku_lobby_display.bundle: compiled Unity asset bundle used by the plugin.

## Settings

- ModEnabled: turns the mod on or off.
- EnableAudio: turns bundled music on or off.
- AudioVolume: music volume. Default 0.1.
- AudioRangeMeters: audible range in meters. Range 1 to 30. Default 5.
- ModelScale: model size. Default 1.2. Maximum 3.
- ModelYawCorrection: horizontal facing correction.
- SpawnModelKey: moves the model to the current grounded placement point. Default F8.

If ModConfig is installed, all settings appear on one page. Otherwise, edit the cfg file directly.

## Update Notes

This release focuses on feature polish and bug fixes.

### Feature Updates

- Added a cleaner single-model display flow for the Airport lobby and hotkey placement.
- Added optional synced music playback for the active dance loop.
- Added visible model shadow support for better scene presence.
- Kept all settings together on one simple ModConfig page.

### Fixes

- Improved animation and audio synchronization during loop playback.
- Reduced playback snapping caused by repeated placement refresh.
- Improved rotation pivot handling so model turning is closer to the real body center.
- Improved grounded placement stability for lobby and in-game spawning.
- Fixed several presentation issues around model visibility, shadow display, and runtime placement behavior.

## Asset Credits and Permissions

This package includes third-party MMD resources only as part of one compiled in-game presentation bundle. All original rights remain with the original creators and rights holders.

- PEAK plugin integration: [Thanks](https://space.bilibili.com/93755540)
- Motion source: [Ponx_迫奈熏 - シンデレラ motion distribution video](https://www.bilibili.com/video/BV1H3411U72N)
- Model source: [Kinsama式初音ミクV4C](https://www.aplaybox.com/u/122072295)
- Model credits from the included readme: character design by 豆の素, copyright by Crypton Future Media, INC., model by Kacha and Kinsama, textures by Ral.

Motion terms from the included readme:
- Editing and adjustment are allowed.
- Free redistribution is allowed.
- Use inside a game or program is allowed with credit to the motion author.
- Commercial use, resale, R18 use, and unlawful use are not allowed.

Model terms from the included readme:
- Commercial, political, religious, violent, gory, and sexual use are not allowed.

Distribution note:
- This mod is a gameplay package, not a standalone asset library.
- It ships only the plugin DLL and one compiled Unity bundle needed at runtime.
- It does not provide loose PMX, VMD, texture, or audio source files for reuse.
- Please do not extract or redistribute bundled third-party assets as standalone resources.
