# MikuShowcase

MikuShowcase adds one non-collidable Miku performance display to PEAK.

The mod shows one default performance display in the Airport lobby and lets the player move that same display to a grounded position with a configurable hotkey.

## Installation

- Install through Thunderstore or extract this package into your PEAK game folder.
- The plugin files are placed in BepInEx/plugins.
- BepInEx generates the config file at BepInEx/config/com.github.Thanks.MikuDance.cfg.

## Package Contents

- com.github.Thanks.MikuShowcase.dll is the PEAK plugin.
- miku_lobby_display.bundle is the compiled Unity asset bundle used by the plugin at runtime.

## Features

- Spawns one lobby display automatically in the Airport scene.
- Moves or respawns that same display to the player's grounded position with a hotkey.
- Supports optional bundled music playback synchronized to the active dance loop.
- Uses a single config file only: com.github.Thanks.MikuDance.cfg.

## Config

If ModConfig is installed, all options appear on one page. Otherwise, edit the generated cfg file directly.

- ModEnabled: main on or off switch.
- EnableAudio: enables or disables bundled music playback.
- AudioVolume: music volume. Default 0.1.
- AudioRangeMeters: audible distance in meters. Range 1 to 30, default 5.
- ModelScale: uniform model scale. Default 1.2. Maximum 3.0.
- ModelYawCorrection: horizontal rotation correction in degrees.
- SpawnModelKey: hotkey used to move the display. Default F8.

## Third-Party Assets and Permissions

This mod bundles third-party MMD resources only as part of one compiled in-game presentation bundle. Ownership, copyright, and any original usage restrictions remain with the original creators and rights holders.

- Plugin integration for PEAK: [Thanks](https://space.bilibili.com/93755540)
- Motion source: [Ponx_迫奈熏 - シンデレラ motion distribution video](https://www.bilibili.com/video/BV1H3411U72N)
- Motion terms from the included motion readme: edits and adjustments are allowed; free redistribution is allowed; use inside a game or program is allowed when the motion author is credited; resale, commercial use, R18 use, and unlawful use are not allowed.
- Model source: [Kinsama式初音ミクV4C](https://www.aplaybox.com/u/122072295)
- Model credits from the included model readme: character design by 豆の素, copyright by Crypton Future Media, INC., model by Kacha and Kinsama, textures by Ral.
- Model terms from the included model readme: the model must not be used for commercial, political, religious, violent, gory, or sexual content.
- Bundled audio is included only to keep the in-game dance playback synchronized. This package does not provide the raw audio as a separate standalone download and does not grant any separate reuse rights for that audio outside this mod package.

## Distribution Notes

- This package is a gameplay mod, not a standalone asset library.
- The runtime package only ships the plugin DLL and one compiled Unity bundle required for the in-game display.
- It does not expose loose PMX, VMD, texture, or audio source files for reuse.
- Please do not extract, reupload, or redistribute bundled third-party assets from this package as standalone resources.
- If any original creator or rights holder requests a change in attribution or removal, the package author should be contacted so the package can be updated.

## Notes

- Only one display instance is used.
- The model has no collision and is for presentation only.
- The plugin first looks for miku_lobby_display.bundle next to the DLL and still accepts older legacy bundle paths for compatibility.
